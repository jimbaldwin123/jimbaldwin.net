// JSON for /products/webx.php
	var xslide = 0; //needs to be global
	var xslides = [
		{
			"image": '11077_NetVis_connect_sm.jpg',
			"large": '11077_NetVis_connect_lg.jpg',
			"title": "Connect",
			"data":[
				
				{
					"label": "",
					"top":457,
					"left":405,
					"callout": "Patch ports quickly between two user-definable groups."
				},
				{
					"label": "",
					"top":282,
					"left":307,
					"callout": "Instead of viewing all ports, users can only view/access ports they are authorized to use."
				},
				{
					"label": "",
					"top":354,
					"left":559,
					"callout": "Port icon sizes are user-settable - featuring more at-a-glance patching info."
				}
			]
		},
		{
			"image": '11077_NetVis_view_sm.jpg',
			"large": '11077_NetVis_view_lg.jpg',
			"title": "View",
			"data":[
				
				{
					"label": "",
					"top":146,
					"left":275,
					"callout": "View Connections offers a quick snapshot of all switch activity. Color-coded indicators quickly alert the user to any issues."
				},
				{
					"label": "",
					"top":177,
					"left":325,
					"callout": "The link status indicator shows green when connections are healthy and red if there is a fault"
				},
				{
					"label": "",
					"top":242,
					"left":386,
					"callout": "The bandwidth indicator adjusts in real time and alerts the user when connections are approaching the point of oversubscription"
				},
				{
					"label": "",
					"top":128,
					"left":570,
					"callout": "Users can customize the screen view to show only the columns that they consider critical"
				}
			]
		},
		{
			"image": '11077_NetVis_filters_sm.jpg',
			"large": '11077_NetVis_filters_lg.jpg',
			"title": "Filters",
			"data":[
				
				{
					"label": "",
					"top":172,
					"left":90,
					"callout": "All saved filters can be accessed from the alphabetically arranged list. Filters can also be imported/exported, so it's easy to share a common set of filters between switches and TITAN <span class='productName'>EnterPoint</span>."
				},
				{
					"label": "",
					"top":178,
					"left":240,
					"callout": "Users can select drop or pass functions, and choose between a list of Layer 2-4 parameters."
				},
				{
					"label": "",
					"top":209,
					"left":270,
					"callout": "Drag-n-drop functionality allows users to easily rearrange individual parameters within a filter. Users can also undo/redo changes."
				},
				{
					"label": "",
					"top":455,
					"left":380,
					"callout": "Users familiar with Wireshark syntax can type complete filter parameters into the criteria field."
				}
			]
		},
		{
			"image": '11077_NetVis_status_sm.jpg',
			"large": '11077_NetVis_status_lg.jpg',
			"title": "Status",
			"data":[
				
				{
					"label": "",
					"top":172,
					"left":185,
					"callout": "Visual presentation of chassis status and health from a single screen, with quick-read indicators to identify any areas of concern.",
					"rollover": {
							"image": 'im_alarm.png',
							"top":160,
							"left":130
						   }
				},
				{
					"label": "",
					"top":423,
					"left":588,
					"callout": "Click on thumbnail images to view more detailed information about specific components of the switch chassis."
				},
				{
					"label": "",
					"top":513,
					"left":98,
					"callout": "Status lights &ndash; viewable from any screen &ndash; give an immediate indication of any switch health concerns."
				}
			]
		}
	];