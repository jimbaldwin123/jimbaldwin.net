	var queryStringObject = {};
	var title_tmp = '\
		<h1 style="margin-top:30px;height:30px;width:500px;"><span class="t1hsc">$title:</span></h1>\
		<img id="screenshot" src="/images/common/$image" />\
	';

	var template_tmp = '\
		<img id="$rollover" class="rollover" style="display:none;position:absolute;top:$rollover_top;left:$rollover_left;" src="/images/common/blank.gif" />\
		<img class="helper" id="$arrow_id" style="position:absolute;top:$top;left:$left;z-index:10;background:transparent;" src="/images/common/$imgButton" />\
		<div class="helper callout" id="$callout_id" style="position:absolute;top: $callout_top;left: $callout_left;">\
			<p style="font-weight:bold;">$label</p>\
			<p>\
				$callout\
			</p>\
		</div>\
	';
	
	var footer_tmp = '\
		<!-- <p>View other APCON interfaces: <a href="netvis.php"><?php echo pn0("NetVis"); ?></a>&nbsp;&nbsp;<a href="enterpoint.php"><?php echo pn0("EnterPoint"); ?></a>&nbsp;&nbsp;<a href="cli.php"><?php echo pn0("CLI"); ?></a>&nbsp;&nbsp;</a></p>-->\
		<div>\
		<p class="rollover_label">Rollover: $rollovers </p>\
		<div style="text-align:center;margin:auto;">\
			<div class="prev_label">$prev_label</div>\
			<div style="float:left;margin-top:10px;">\
			<img id="prev" src="/images/common/11077_bt_prev.png" />\
			<img id="next" src="/images/common/11077_bt_next.png" />\
			</div>\
			<div class="next_label">$next_label</div>\
			<div style="float: left;margin-top:7px;"><a id="lb" href="/images/common/$large" rel="lightbox" title="$title">Enlarge View<img src="/images/common/11077_magnify.png" /></a></div>\
		</div>\
		</div>\
	';
	var WWW = {
		renderPage: function(which_slide) {
			if(window._gaq){
				_gaq.push(['_trackPageview']);
			}
			var template = '';
			var callout_mess = '';
			var footer = footer_tmp;
			var title = title_tmp;
			
			xslide = which_slide;
			title = title.replace('$title',xslides[which_slide].title);
			// $j('title').html('APCON, Inc. | Embedded Switch Management Software' + ' - ' + xslides[which_slide].title);
			title = title.replace('$image',xslides[which_slide].image);
			var data = xslides[which_slide].data
			for(i=0;i<data.length;i++){
				var j = i+1;
				template = template_tmp;
				template = template.replace('$arrow_id','ports_'+j+'_arrow');
				template = template.replace('$callout_id','ports_'+j+'_callout');
				template = template.replace('$top',data[i].top+'px');
				template = template.replace('$left',data[i].left+'px');
				var callout_top = data[i].top + 2;
				var callout_left = data[i].left + 6;
				template = template.replace('$callout_top',callout_top+'px');
				template = template.replace('$callout_left',callout_left+'px');
				// var imgButton = '11077_arrow_0'+j+'.png';
				var imgButton = '11077_arrow_anim.gif';
				template = template.replace('$imgButton',imgButton);
				template = template.replace('$label',data[i].label);
				template = template.replace('$callout',data[i].callout);
				if(data[i].rollover !== undefined){
					template = template.replace('$rollover','rollover'+j);
					template = template.replace('$rollover_top',data[i].rollover.top+'px');
					template = template.replace('$rollover_left',data[i].rollover.left+'px');
					template = template.replace('blank.gif',data[i].rollover.image);
				}
				
				callout_mess += template;
			}
			var pn_nums = this.prevNextNum(which_slide);
			// console.log(pn_nums);
			footer = footer.replace('$prev_label','<a href="#" onclick="WWW.renderPage('+pn_nums[0]+'); return false;">'+xslides[pn_nums[0]].title+'</a>');
			footer = footer.replace('$next_label','<a href="#" onclick="WWW.renderPage('+pn_nums[1]+'); return false;">'+xslides[pn_nums[1]].title+'</a>');
			footer = footer.replace('$title',xslides[which_slide].title);
			footer = footer.replace('$large',xslides[which_slide].large);
			footer = footer.replace('$title2',xslides[which_slide].title);
			footer = footer.replace('$large2',xslides[which_slide].large);
			callout_mess = title + callout_mess + footer;
			// console.log(footer);
			
			$j('#main_slide').html(callout_mess);
			//bind clicks to arrows
			$j('#prev').click(function(){
				WWW.changeSlide(-1);
				return false;
			})
			$j('#next').click(function(){
				WWW.changeSlide(1);
				return false;
			})
			//bind hover events to .helpers
			$j('.helper').each(function(i){
				
				var h = $j(this).attr('id');
				var h1 = h.replace("arrow","callout");
				var h2 = h.replace("callout","arrow");
				var az = h.split('_')[1];
	
				$j(this).hover(
					function(){
						if(h1 == h){ // it's a callout
							$j('#'+h).css('z-index',11);
							$j('#'+h2).css('z-index',12);
						}else{ //it's an arrow
							$j('#'+h1).css('z-index',11);
							$j('#'+h).css('z-index',12);
						}
						$j('#'+h1).show();
						$j('#rollover'+az).show();
					},
					function(){
						$j('#'+h).css('z-index',10);
						$j('#'+h1).hide();
						$j('#rollover'+az).hide();
					}
				)
			});
			$j('#stuff'+xslide).css('font-weight','bold');
			doReplace(); //sIFRs
			$j('#lightbox').remove();
			$j('#overlay').remove();
			$j("a[rel='lightbox']").lightBox();
			//initLightbox();
			
		},
		prevNextNum: function(num){
			var prev = this.indexWrap(num-1);
			var next = this.indexWrap(num+1);
			return [prev,next];
		},
		changeSlide: function(inc) {
			xslide += inc;
			xslide = this.indexWrap(xslide);
			this.renderPage(xslide);
		},
		indexWrap: function(index){
			if(index < 0){
				index = xslides.length - 1;
			}
			if(index > xslides.length - 1){
				index = 0;
			}
			return index;
		}
	}