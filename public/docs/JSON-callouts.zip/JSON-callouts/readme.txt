These are JSON files and a redering code built in JavaScript without any framework such as jQuery. The pages they display are at http://utility2012.apcon.com. Those pages are out of my control and are somewhat broken -- the navbar layout is broken and the lightbox ("Enlarge View") is broken. However, the JSON and rendering functionality still work.

The JSON and rendering code implement the callouts and slideshow functionality on each page. 

The pages are at:

http://utility2012.apcon.com/products/webx.php
http://utility2012.apcon.com/products/netvis.php
http://utility2012.apcon.com/products/enterpoint.php
