
	$j(document).ready(function(){
		//preload slides, set bottom nav
		var r = '';
		
		for(i=0;i<xslides.length;i++){
			var j = i+1;
			r += '<a class="stuff" id="stuff'+i+'" href="#" onclick="WWW.renderPage('+i+');">'+j+' </a>';
			$j('.bc1').append('<img class="preload" src="/images/common/'+xslides[i].image+'" />');
		}
		footer_tmp = footer_tmp.replace('$rollovers',r);
		queryStringObject = qs2obj();
		var p = queryStringObject.p;
		if(isNaN(p) || p > xslides.length || p < 0){
			p = 0;
		}
		p = parseInt(p);
		WWW.renderPage(p);
		$j("a[rel='lightbox']").lightBox();
	});
