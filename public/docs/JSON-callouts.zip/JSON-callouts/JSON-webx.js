// JSON for /products/webx.php
	var xslide = 0; //needs to be global
	var xslides = [
		{
			"image": '11077_global_view.jpg',
			"large": '11077_global_view_lg.jpg',
			"title": "Global View",
			"data":[
				
				{
					"label": "",
					"top":150,
					"left":125,
					"callout": "Switch overview information details model number, software version and switch name"
				},
				{
					"label": "",
					"top":128,
					"left":565,
					"callout": "Flexible options allow users to quickly customize Global View to their individual preferences"
				},
				{
					"label": "",
					"top":332,
					"left":125,
					"callout": "Switch segments function like virtual folders for storing and organizing diagrams"
				},
				{
					"label": "",
					"top":357,
					"left":320,
					"callout": "Alert lights give quick visual indications of connection status and bandwidth "
				},
				{
					"label": "",
					"top":272,
					"left":540,
					"callout": "Open a segment for thumbnail views and status of each diagram"
				}

			]
		},
		{
			"image": '11077_global_view_diagramming.jpg',
			"large": '11077_global_view_diagramming_lg.jpg',
			"title": "Diagramming",
			"data":[
				
				{
					"label": "",
					"top":195,
					"left":185,
					"callout": "Drag-n-drop or double-click on ports to add them to the diagram screen"
				},
				{
					"label": "",
					"top":151,
					"left":221,
					"callout": "Select a tool to create connections &ndash; either simplex or duplex &ndash; between ports"
				},
				{
					"label": "",
					"top":192,
					"left":350,
					"callout": "Ports are color-coded to indicate source or destination "
				},
				{
					"label": "",
					"top":307,
					"left":404,
					"callout": "Connection cubes turn red to indicate when a connection is not allowed &ndash; for instance when incompatible ports types are selected",
					"rollover": {
							"image": 'im_connection_red.png',
							"top":306,
							"left":387
						   }
				},
				{
					"label": "",
					"top":240,
					"left":589,
					"callout": "Users can customize the port viewing size for the amount of detail they prefer to see"
				},
				{
					"label": "",
					"top":323,
					"left":565,
					"callout": "Port tagging makes it simple to determine the source of monitoring traffic"
				}
			]
		},
		{
			"image": '11077_global_view_load_balance.jpg',
			"large": '11077_global_view_load_balance_lg.jpg',
			"title": "Load Balancing",
			"data":[
				{
					"label": "",
					"top":442,
					"left":186,
					"callout": "APCON's load balancing technology maintains flows &ndash; automatically routing traffic from a single conversation to a single destination port"
				},				
				{
					"label": "",
					"top":202,
					"left":470,
					"callout": "Use a single source, or aggregate multiple source ports, as input for a load balance group"
				},
				{
					"label": "",
					"top":338,
					"left":562,
					"callout": "Include up to eight ports in each load balance group, and create multiple load balance groups on a single blade."
				}
			]
		},
		{
			"image": '11077_ports.jpg',
			"large": '11077_ports_lg.jpg',
			"title": "Ports",
			"data":[
				
				{
					"label": "",
					"top":175,
					"left":48,
					"callout": "Ports display port name, link status and type of active connection. Right-click functionality offers an extensive menu of options."
				},
				{
					"label": "",
					"top":315,
					"left":182,
					"callout": "Icons give quick visual indications of port locking and filtered connections"
				},
				{
					"label": "",
					"top":521,
					"left":265,
					"callout": "The TITAN Active Sync indicator alerts the user that this switch is managed by TITAN <span class='productName'>EnterPoint</span> multi-switch management software"
				}
			]
		},
		{
			"image": '11077_view.jpg',
			"large": '11077_view_lg.jpg',
			"title": "View",
			"data":[
				
				{
					"label": "",
					"top":145,
					"left":275,
					"callout": "View Connections offers a quick snapshot of all switch activity. Color-coded indicators quickly alert the user to any issues."
				},
				{
					"label": "",
					"top":202,
					"left":327,
					"callout": "The link status indicator shows green when connections are healthy and red if there is a fault"
				},
				{
					"label": "",
					"top":261,
					"left":387,
					"callout": "The bandwidth indicator adjusts in real time and alerts the user when connections are approaching the point of oversubscription"
				},
				{
					"label": "",
					"top":128,
					"left":570,
					"callout": "Users can customize the screen view to show only the columns that they consider critical"
				}
			]
		},
		{
			"image": '11077_filters.jpg',
			"large": '11077_filters_lg.jpg',
			"title": "Filters",
			"data":[
				
				{
					"label": "",
					"top":172,
					"left":90,
					"callout": "All saved filters can be accessed from the alphabetically arranged list. Filters can also be imported/exported, so it's easy to share a common set of filters between switches and TITAN <span class='productName'>EnterPoint</span>."
				},
				{
					"label": "",
					"top":178,
					"left":240,
					"callout": "Users can select drop or pass functions, and choose between a list of Layer 2-4 parameters."
				},
				{
					"label": "",
					"top":209,
					"left":270,
					"callout": "Drag-n-drop functionality allows users to easily rearrange individual parameters within a filter. Users can also undo/redo changes."
				},
				{
					"label": "",
					"top":455,
					"left":380,
					"callout": "Users familiar with Wireshark syntax can type complete filter parameters into the criteria field."
				}
			]
		},
		{
			"image": '11077_status.jpg',
			"large": '11077_status_lg.jpg',
			"title": "Status",
			"data":[
				
				{
					"label": "",
					"top":172,
					"left":185,
					"callout": "Visual presentation of chassis status and health from a single screen, with quick-read indicators to identify any areas of concern.",
					"rollover": {
							"image": 'im_alarm.png',
							"top":160,
							"left":130
						   }
				},
				{
					"label": "",
					"top":423,
					"left":588,
					"callout": "Click on thumbnail images to view more detailed information about specific components of the switch chassis."
				},
				{
					"label": "",
					"top":513,
					"left":98,
					"callout": "Status lights &ndash; viewable from any screen &ndash; give an immediate indication of any switch health concerns."
				}
			]
		}
	];