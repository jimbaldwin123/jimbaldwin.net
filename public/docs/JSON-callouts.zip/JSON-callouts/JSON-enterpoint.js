//JSON for /products/enterpoint.php
	var xslide = 0; //needs to be global
	var xslides = [
		{
			"image": '11083_Global_View.jpg',
			"large": '11083_Global_View_lg.jpg',
			"title": "Global View",
			"data":[
				
				{
					"label": "",
					"top":193,
					"left":110,
					"callout": "Site list indicates all locations for installed APCON switches, as well as switch status"
				},
				{
					"label": "",
					"top":431,
					"left":140,
					"callout": "Active Sessions shows all existing connections for the highlighted site"
				},
				{
					"label": "",
					"top":381,
					"left":479,
					"callout": "Overview information details number, location and status of APCON switches<br><br>Alert lights give quick visual indications of connection status and bandwidth"
				}

			]
		},
		{
			"image": '11083_Status.jpg',
			"large": '11083_Status_lg.jpg',
			"title": "Switch Status",
			"data":[
				
				{
					"label": "",
					"top":177,
					"left":160,
					"callout": "List of all APCON switches managed by <span class='productName'>EnterPoint</span>"
				},
				{
					"label": "",
					"top":192,
					"left":576,
					"callout": "Visual overview of the selected APCON switch"
				},
				{
					"label": "",
					"top":392,
					"left":300,
					"callout": "Visual indicators display the health and status of the selected APCON switch"
				}
			]
		},
		{
			"image": '11083_Connections.jpg',
			"large": '11083_Connections_lg.jpg',
			"title": "Connections",
			"data":[
				{
					"label": "",
					"top":172,
					"left":58,
					"callout": "Display ports to connect on a site-by-site basis"
				},
				{
					"label": "",
					"top":335,
					"left":365,
					"callout": "Build connections in the same intuitive style as the single-switch management software <span class='productName'>NetVis</span>"
				}
			]
		},
		{
			"image": '11083_Filters.jpg',
			"large": '11083_Filters.jpg',
			"title": "Filters",
			"data":[
				
				{
					"label": "",
					"top":167,
					"left":100,
					"callout": "Filters can be imported from individual switches into <span class='productName'>EnterPoint</span> &ndash; saving time and avoiding manual errors"
				},
				{
					"label": "",
					"top":278,
					"left":277,
					"callout": "Build filters in the same intuitive style as the single-switch management software"
				}
			]
		},
		{
			"image": '11083_Calendar.jpg',
			"large": '11083_Calendar_lg.jpg',
			"title": "Scheduling",
			"data":[
				
				{
					"label": "",
					"top":172,
					"left":85,
					"callout": "Displays all end devices that can be connected by <span class='productName'>EnterPoint</span>"
				},
				{
					"label": "",
					"top":162,
					"left":458,
					"callout": "Device usage bars show green for active connectors"
				},
				{
					"label": "",
					"top":227,
					"left":298,
					"callout": "Device usage bars show yellow for pending connections that are reserved"
				}
			]
		},
		{
			"image": '11083_Reports.jpg',
			"large": '11083_Reports_lg.jpg',
			"title": "Reports",
			"data":[
				
				{
					"label": "",
					"top":145,
					"left":140,
					"callout": "<span class='productName'>EnterPoint</span> offers a range of standard reports. Users can also build and save custom reports."
				},
				{
					"label": "",
					"top":255,
					"left":488,
					"callout": "Users have a range of search criteria from which to select when building reports."
				},
				{
					"label": "",
					"top":362,
					"left":488,
					"callout": "Criteria appear below as fields are selected for reporting."
				}
			]
		}
	];