 # -*- coding: utf-8 -*-
"""
	Convert base 60 lat/long to decimal
	2014-02-25 JLB
	input file input.csv
	output
		- result csv file
		- dump.csv containing non-utf8 chars that need to be replaced manually
	run and replace dump.csv entries until dump.csv is clean
"""
import csv

def sdec(data): # convert sexigesmal to dec
    """convert sexigesmal to dec"""
    retval = 0
    denominator = 1
    for val in data:
        val=float(val)
        retval += val/denominator
        denominator*=60
    return retval

def isBase60(val):
    """returns boolean is base60"""
    if val.find("\"\"",1) > 0:
        return 1
    if val.find("'") > 0:
        return 1
    return 0

def preformat(s):
    """clean up input fields"""
    s = s.strip('"')
    s = s.strip(' ')
    s = s.replace('""','"')
    s = s.replace(' ','')
    return s

def s2d(s):
    """
    base60 to dec
    trim
    dupe
    sign
    convert
    """
    """
    w = (s+', ')
    for z in s:
        w += str(ord(z)) + ' '
        print ord(z)
    w += "\n"
    f.write(w)
    """
    print s
    s = preformat(s)
    #convert compass direction symbol to sign
    sign = ''
    if s[-1] == 'S' or s[-1] == 'W':
        sign = '-'
    #remove compass symbol
    s = s[:-1]
    
    #get degrees
    dp = s.find(chr(194))
   
    if dp > 0:
        #get degrees
        deg = float(s[:dp])
  	
	#strip degrees symbol
        s = s[dp+2:]
        s = s.strip(chr(194))
    else:
        deg = 0
    
    #get minutes
    mp = s.find("'")
    if mp > 0:
        print ord(s[0])
        min = float(s[:mp])
        s = s[mp+1:]
    else:
        min = 0
        
    #get seconds
    sp = s.find("\"")
    if sp > 0:
        sec = float(s[:sp])
        s = s[sp+1:]
    else:
        sec = 0

    #calculate decimal degrees
    dd = deg + min/60 + sec/3600
    dd = sign + str(dd)
    return dd

def d2d(s):

    #dec to dec
    s = preformat(s)
    #convert compass symbol to sign
    sign = ''
    if s[-1] == 'S' or s[-1] == 'W':
        sign = '-'

    #remove spaces and degree symbol
    s = s.replace(' ','')
    s = s.replace(chr(176),'')
    s = s.replace(chr(194),'')
    
    #remove compass symbol
    s = s[:-1]
    s = sign + s
    return s

f2 = open("Nothochrysinae-decimal-geo.csv","w")
f = open("dump.csv","w")
csvFile = csv.reader(open('input.csv','r'),delimiter=',',quotechar='"')
i=0
for row in csvFile:

    i+=1
    #if empty row
    if len(row) == 0:
        continue

    #if field name row, write to output and continue
    if row[0] == 'genus':
        row.insert(3,'latitude-decimal')
        row.insert(5,'longitude-decimal')
        sout = ",".join(row) +"\n"
        f2.write(sout)
        continue

    name = row[0]
    lat = row[2]
    long = row[3]

    #if geo data empty
    if len(lat) == 0:
        row.insert(3,'')
        row.insert(5,'')
        sout = ",".join(row) +"\n"
        f2.write(sout)
        continue
    
    if isBase60(lat):
        dlat = s2d(lat)
    else:
	#diagnostic dump of non-utf8 characters
        dlat = d2d(lat)
        s=dlat
        w = (s+', ')
        for z in s:
            w += str(ord(z)) + ' '
        w += "\n"
        f.write(w)

    if isBase60(long):
        dlong = s2d(long)
    else:
        dlong = d2d(long)
        
    row[2] = preformat(row[2])
    row[3] = preformat(row[3])
    row.insert(3,dlat)
    row.insert(5,dlong)
    sout = ",".join(row) +"\n"
    f2.write(sout)

f2.close()
f.close()
